/**
 * Server-side authorization guards.
 *
 * These functions throw `AuthenticationError` or `AuthorizationError` and are
 * meant to be called at the top of server functions that protect restricted
 * resources.
 */

import { eq } from "drizzle-orm";
import { db } from "../../db/index.ts";
import { technicianProfiles } from "../../db/schema.ts";
import {
	type AuthenticatedUser,
	AuthorizationError,
	requireRole,
} from "./session.ts";

export interface AuthenticatedTechnician extends AuthenticatedUser {
	technicianProfileId: string;
}

/**
 * Requires the caller to be an approved, active technician.
 *
 * - Calls `requireRole('technician')` first (throws if not authenticated or not a technician).
 * - Then verifies `verificationStatus === 'approved'` AND `activeStatus === 'active'`.
 * - Returns the authenticated user object augmented with `technicianProfileId`.
 */
export async function requireApprovedActiveTechnician(): Promise<AuthenticatedTechnician> {
	const user = await requireRole("technician");

	const [profile] = await db
		.select({
			id: technicianProfiles.id,
			verificationStatus: technicianProfiles.verificationStatus,
			activeStatus: technicianProfiles.activeStatus,
		})
		.from(technicianProfiles)
		.where(eq(technicianProfiles.userId, user.id))
		.limit(1);

	if (
		!profile ||
		profile.verificationStatus !== "approved" ||
		profile.activeStatus !== "active"
	) {
		throw new AuthorizationError();
	}

	return { ...user, technicianProfileId: profile.id };
}
