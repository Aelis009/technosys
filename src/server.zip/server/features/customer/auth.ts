/**
 * Customer authentication server functions.
 *
 * Flow:
 *  1. requestCustomerLoginOtp(mobile)  – rate-limited OTP generation
 *  2. verifyCustomerLoginOtp(mobile, otp) – verify OTP, auto-create account if new user, create session
 */

import { createServerFn } from "@tanstack/react-start";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "../../../db/index.ts";
import {
	customerProfiles,
	roles,
	userRoles,
	users,
} from "../../../db/schema.ts";
import { csrfMiddleware } from "../../auth/csrf.ts";
import { requestOtp, verifyOtp } from "../../auth/otp.ts";
import { createSession } from "../../auth/session.ts";

// ─── validation schemas ───────────────────────────────────────────────────────

const indianMobileSchema = z
	.string()
	.trim()
	.regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit Indian mobile number.");

const requestOtpInputSchema = z.object({
	mobile: indianMobileSchema,
});

const verifyOtpInputSchema = z.object({
	mobile: indianMobileSchema,
	otp: z
		.string()
		.trim()
		.length(6, "OTP must be exactly 6 digits.")
		.regex(/^\d{6}$/, "OTP must be numeric."),
});

// ─── requestCustomerLoginOtp ─────────────────────────────────────────────────

export const requestCustomerLoginOtp = createServerFn({ method: "POST" })
	.middleware([csrfMiddleware])
	.validator((raw: unknown) => requestOtpInputSchema.parse(raw))
	.handler(async ({ data }) => {
		const result = await requestOtp({
			mobile: data.mobile,
			purpose: "customer_login",
		});
		return result;
	});

// ─── verifyCustomerLoginOtp ──────────────────────────────────────────────────

export const verifyCustomerLoginOtp = createServerFn({ method: "POST" })
	.middleware([csrfMiddleware])
	.validator((raw: unknown) => verifyOtpInputSchema.parse(raw))
	.handler(async ({ data }) => {
		// 1. Verify the OTP (throws OtpError on failure)
		await verifyOtp({
			mobile: data.mobile,
			otp: data.otp,
			purpose: "customer_login",
		});

		// 2. Look up existing user by mobile
		const [existingUser] = await db
			.select({
				id: users.id,
				isActive: users.isActive,
			})
			.from(users)
			.where(eq(users.mobile, data.mobile))
			.limit(1);

		let userId: string;
		let isNewUser = false;

		if (existingUser) {
			// Existing user checks
			if (!existingUser.isActive) {
				throw new Error(
					"Your account has been deactivated. Please contact support.",
				);
			}

			// Ensure they have the customer role (not admin or technician-only)
			const [customerRole] = await db
				.select({ id: roles.id })
				.from(roles)
				.where(eq(roles.name, "customer"))
				.limit(1);

			if (!customerRole) {
				throw new Error(
					"Customer role is not configured. Please contact support.",
				);
			}

			const [hasCustomerRole] = await db
				.select({ id: userRoles.id })
				.from(userRoles)
				.where(
					and(
						eq(userRoles.userId, existingUser.id),
						eq(userRoles.roleId, customerRole.id),
					),
				)
				.limit(1);

			if (!hasCustomerRole) {
				// User exists but doesn't have customer role (e.g., technician trying customer login)
				throw new Error(
					"This mobile number is registered under a different account type.",
				);
			}

			userId = existingUser.id;
		} else {
			// New user: create user + customer role + customer profile in one transaction
			const [customerRole] = await db
				.select({ id: roles.id })
				.from(roles)
				.where(eq(roles.name, "customer"))
				.limit(1);

			if (!customerRole) {
				throw new Error(
					"Customer role is not configured. Please contact support.",
				);
			}

			const newUserId = await db.transaction(async (tx) => {
				const [newUser] = await tx
					.insert(users)
					.values({
						name: null,
						mobile: data.mobile,
						isMobileVerified: true,
						isActive: true,
					})
					.returning({ id: users.id });

				if (!newUser) throw new Error("Failed to create user record.");

				await tx.insert(userRoles).values({
					userId: newUser.id,
					roleId: customerRole.id,
				});

				await tx.insert(customerProfiles).values({
					userId: newUser.id,
				});

				return newUser.id;
			});

			userId = newUserId;
			isNewUser = true;
		}

		// 3. Create session (sets cookie server-side)
		await createSession(userId);

		return { success: true as const, isNewUser };
	});
