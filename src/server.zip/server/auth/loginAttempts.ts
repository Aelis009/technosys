/**
 * Login-attempt rate-limiting service.
 *
 * Uses the `login_attempts` table to track failures per identifier (email / mobile string).
 * After 5 failed attempts the identifier is blocked for 15 minutes.
 */

import { eq } from "drizzle-orm";
import { db } from "../../db/index.ts";
import { loginAttempts } from "../../db/schema.ts";
import { AuthenticationError } from "./session.ts";

const MAX_ATTEMPTS = 5;
const BLOCK_DURATION_MS = 15 * 60 * 1000; // 15 minutes

/**
 * Throws `AuthenticationError` if the identifier is currently blocked.
 * Call this BEFORE checking credentials.
 */
export async function checkLoginBlock(identifier: string): Promise<void> {
	const key = identifier.toLowerCase().trim();
	const now = new Date();

	const [row] = await db
		.select({ blockedUntil: loginAttempts.blockedUntil })
		.from(loginAttempts)
		.where(eq(loginAttempts.identifier, key))
		.limit(1);

	if (row?.blockedUntil && row.blockedUntil > now) {
		const minutesLeft = Math.ceil(
			(row.blockedUntil.getTime() - now.getTime()) / 60_000,
		);
		throw new AuthenticationError(
			`Too many failed login attempts. Try again in ${minutesLeft} minute(s).`,
		);
	}
}

/**
 * Records a failed login attempt.
 * Upserts the row; blocks the identifier if attempts reach `MAX_ATTEMPTS`.
 */
export async function recordFailedAttempt(identifier: string): Promise<void> {
	const key = identifier.toLowerCase().trim();
	const now = new Date();

	const [existing] = await db
		.select({ id: loginAttempts.id, attempts: loginAttempts.attempts })
		.from(loginAttempts)
		.where(eq(loginAttempts.identifier, key))
		.limit(1);

	if (existing) {
		const newAttempts = existing.attempts + 1;
		const blockedUntil =
			newAttempts >= MAX_ATTEMPTS
				? new Date(now.getTime() + BLOCK_DURATION_MS)
				: null;

		await db
			.update(loginAttempts)
			.set({ attempts: newAttempts, blockedUntil, updatedAt: now })
			.where(eq(loginAttempts.id, existing.id));
	} else {
		await db.insert(loginAttempts).values({
			identifier: key,
			attempts: 1,
			blockedUntil: null,
		});
	}
}

/**
 * Resets the attempt counter after a successful login.
 */
export async function clearLoginAttempts(identifier: string): Promise<void> {
	const key = identifier.toLowerCase().trim();
	const now = new Date();

	await db
		.update(loginAttempts)
		.set({ attempts: 0, blockedUntil: null, updatedAt: now })
		.where(eq(loginAttempts.identifier, key));
}
